package testRunner;

import org.junit.runner.RunWith;

import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;
import io.cucumber.junit.CucumberOptions.SnippetType;

@RunWith(Cucumber.class)

@CucumberOptions(
features = {"src/test/resources/AppFeature/LoginDemo.feature"},
glue = {"stepDefination"},
publish = true  //generate the report
//snippets = SnippetType.CAMELCASE
//monochrome = true          //giving output as more readable format
//tags="@boxbookmark or @createbookmark",     //run the scenario which having tag boxbookmark or createbookmark
//tags="@boxbookmark and  @deletebookmark"   //run the scenario which having both tag boxbookmark and deletebookmark
//tags = "not @createbookmark          //exclude the scenario which have createbookmark tag
              
//dryRun = true
//snippets = SnippetType.UNDERSCORE
//plugin = { "pretty",
//				"junit:target/JUnitReports/report.xml", "json:target/JSONReports/report.json",
//				"html:target/HtmlReports" }

)
public class UberTestRunner {

}
