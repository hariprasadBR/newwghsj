package stepDefination;

import java.time.Duration;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import io.cucumber.java.en.*;

public class LoginDemoSteps3 {
	WebDriver driver;
	WebDriverWait wait;

	@Given("browser is open")
	public void browser_is_open() {
		driver = new ChromeDriver();
	}

	@Given("user is on login page")
	public void user_is_on_login_page() {
		driver.get("https://account.box.com/login");
		driver.manage().window().maximize();
		wait = new WebDriverWait(driver, Duration.ofSeconds(30));
	}

	

}
