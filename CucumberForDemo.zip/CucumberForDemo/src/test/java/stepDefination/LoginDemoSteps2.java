package stepDefination;

import java.time.Duration;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import io.cucumber.java.en.*;

public class LoginDemoSteps2 {
	WebDriver driver;
	WebDriverWait wait;

	

	@When("user enters {string} and {string}")
	public void user_enters_and(String username, String password) {
		WebElement enterEmailID = wait.until(ExpectedConditions.presenceOfElementLocated(By.id("login-email")));

		enterEmailID.sendKeys(username);

		WebElement clickOnNextButton = wait.until(ExpectedConditions.elementToBeClickable(By.id("login-submit")));

		clickOnNextButton.click();

		WebElement enterPassword = wait.until(ExpectedConditions.presenceOfElementLocated(By.id("password-login")));

		enterPassword.sendKeys(password);
	}

	@When("user clicks on login")
	public void user_clicks_on_login() {
		WebElement loginButton = wait.until(ExpectedConditions.elementToBeClickable(By.id("login-submit-password")));

		loginButton.click();

	}

	@Then("user is navigated to the home page")
	public void user_is_navigated_to_the_home_page() {

		driver.quit();
	}

}
