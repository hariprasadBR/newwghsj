package stepDefination;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class UberStepDefination {

//	@Given("user want to select car type {string} from uber app")
//
//	public void userWantToSelectCarTypeFromUberApp(String carType) {
//		System.out.println("car type is :" + carType);
//
//	}
//
//	@When("user select the car {string} and pick up point {string} and drop point {string}")
//	public void userSelectTheCarAndPickUpPointAndDropPoint(String carType, String pickUpLocation,
//			String dropUpLocation) {
//		System.out.println("carType : " + carType + "  pickUpLocation: " + pickUpLocation + " dropUpLocation: " +" "+ dropUpLocation);
//	}
//
//	@Then("driver starts the journey")
//	public void driverStartsTheJourney() {
//		System.out.println("driver start the journey");
//	}
//
//	@Then("driver end the journey")
//	public void driverEndTheJourney() {
//		System.out.println("Driver end the journey");
//	}
//
//	@Then("user pay {int} rupee")
//	public void userPayRupee(Integer price) {
//
//		System.out.println("user pay rupee:" + price);
//	}

}
