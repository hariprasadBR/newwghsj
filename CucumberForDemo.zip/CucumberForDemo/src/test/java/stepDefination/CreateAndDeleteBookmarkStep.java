package stepDefination;

import java.time.Duration;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class CreateAndDeleteBookmarkStep {
	WebDriver driver;
	WebDriverWait wait;
	//final String urlName;

	@Before()
	public void browserSetup() {

		System.out.println("Before" + " I am inside browserSetup");
	}

	@After()
	public void afterTeardown() {
		driver.quit();

	}

	@Given("I open browser {string}")
	public void iOpenBrowser(String browserName) {
		if (browserName.equals("firefox"))
			driver = new FirefoxDriver();
		if (browserName.equals("chrome"))
			driver = new ChromeDriver();
	}

	@When("I navigate into Box app")
	public void iNavigateIntoBoxApp() {
		wait = new WebDriverWait(driver, Duration.ofSeconds(90));
		String appUrl = "https://app.box.com/";
		driver.get(appUrl);
		driver.manage().window().maximize();
	}

	@Then("page with the title {string} should open")
	public void pageWithTheTitleShouldOpen(String pageTitle) throws InterruptedException {
		Thread.sleep(3000);
		boolean flag = wait.until(ExpectedConditions.titleContains(pageTitle));
		Assert.assertTrue("Given title could not be found", flag);
	}

	@When("user login to the Box app with {string} and {string}")
	public void userLoginToTheBoxAppWithAnd(String user, String password) {
		wait.until(ExpectedConditions.presenceOfElementLocated(By.cssSelector("input[name=\"login\"]"))).sendKeys(user);

		wait.until(ExpectedConditions.presenceOfElementLocated(By.cssSelector("button[type=\"submit\"]"))).click();
		WebElement passwordField = wait
				.until(ExpectedConditions.presenceOfElementLocated(By.cssSelector("input[name=\"password\"]")));
		passwordField.sendKeys(password);
		wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector("button[type=\"submit\"]"))).click();
	}

	@Given("create the new bookmark and pass the URL and {string}")
	public void createTheNewBookmarkAndPassTheURLAnd(String string) throws InterruptedException {
		Thread.sleep(10000);

		WebElement newButton = wait.until(
				ExpectedConditions.presenceOfElementLocated(By.xpath("//button[@data-testid='new-item-menu-button']")));
		newButton.click();

		WebElement clickonBookMark = wait
				.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//span[text()='Bookmark']")));

		clickonBookMark.click();
		final String urlName = "Test" + Math.random();

		WebElement clickURLBookMark = wait
				.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//input[@name='url']")));

		clickURLBookMark.sendKeys(urlName);

		WebElement clickonCretaeButton = wait.until(ExpectedConditions
				.presenceOfElementLocated(By.xpath("//span[@class='btn-content']//span[text()='Create']")));

		clickonCretaeButton.click();
	}

	@Then("Verify success message {string}")
	public void verifySuccessMessage(String string) throws InterruptedException {
		WebElement successText = wait.until(ExpectedConditions
				.visibilityOfElementLocated(By.xpath("//span[contains(text(),'was created successfully')]")));

		System.out.println(successText.getText());
		Thread.sleep(3000);
	}

	@Given("Click on the trash and Delete the bookmark")
	public void clickOnTheTrashAndDeleteTheBookmark() throws InterruptedException {
		Thread.sleep(3000);

		Actions action = new Actions(driver);

		WebElement selectOnDeleteCheckBox = wait
				.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//input[@name='select-checkbox']")));

		action.moveToElement(selectOnDeleteCheckBox).click().perform();

		WebElement ClickOnTrashButton = wait
				.until(ExpectedConditions.presenceOfElementLocated(By.cssSelector("button[aria-label='Trash']")));

		ClickOnTrashButton.click();
		Thread.sleep(3000);

		WebElement ClickOndeleteOK = wait
				.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//span[text()='Okay']")));

		ClickOndeleteOK.click();

	}

	@Then("Verify delete message {string}")
	public void verifyDeleteMessage(String string) throws InterruptedException {
		WebElement successfullyMovedInTrash = wait.until(ExpectedConditions
				.visibilityOfElementLocated(By.xpath("//span[contains(text(),'Item successfully moved to trash.')]")));

		Assert.assertEquals(successfullyMovedInTrash.getText(), "Item successfully moved to trash.");

		WebElement ClickOncloseMSG = wait
				.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[@class='close-btn']")));

		ClickOncloseMSG.click();

	}

}
